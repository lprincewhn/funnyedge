import logging
import multi_origin

logging.basicConfig()
logger = logging.getLogger("origin-request")

def lambda_handler(event, context):
    request = event['Records'][0]['cf']['request']
    try:
        request = multi_origin.handler(request)
        return request
    except:
        return request

