import json
import logging
import traceback
import multi_origin

logging.basicConfig()
logger = logging.getLogger("origin-request")

def lambda_handler(event, context):
    request = event['Records'][0]['cf']['request']
    return multi_origin.handler(request)

